link of All Day03 Questions solution : https://day-01-of-90daysofdevops.hashnode.dev/90daysofdevops
