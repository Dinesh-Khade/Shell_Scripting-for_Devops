#!/bin/bash


<< Task

Write a bash script createDirectories.sh that, when executed with three arguments (directory name, start number of directories, and end number of directories), creates a specified number of directories with a dynamic directory name.
Task


read -p "Who much Directories you want :" Directories


echo "$Directories"

if [[$Directories -le $Directories]];
then

