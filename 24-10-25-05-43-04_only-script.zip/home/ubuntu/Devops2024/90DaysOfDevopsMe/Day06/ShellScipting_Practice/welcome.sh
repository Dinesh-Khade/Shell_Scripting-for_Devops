#!/bin/bash

# hello everyone this is my first shellscript

<< note 
My Name is Dinesh and i am learning now ShellScripting for Devops
note

echo "Hello and welcome everyone in class shellScript for Devops"

date
echo ""
echo "Please Share your daily exprience on linkedin"


