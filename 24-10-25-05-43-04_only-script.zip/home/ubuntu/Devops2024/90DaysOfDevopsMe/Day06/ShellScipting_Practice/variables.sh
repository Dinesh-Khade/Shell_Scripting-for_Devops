#!/bin/bash


<< Variable
 Using variable in script
Variable

read -p "enter your name " name


echo "my name is $name"


read -p "Your intrest :" intrest 


echo "my intrest in $intrest"

