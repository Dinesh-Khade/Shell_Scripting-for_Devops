#!/bin/bash
 

<< Variable
this is for learning variables (shellscript)
Variable


read -p "enter your name : " name

echo "my name is $name"
echo ""
read -p "enter your dream job" Dream

echo "my Dream job is $Dream"



