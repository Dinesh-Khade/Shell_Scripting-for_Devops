#!/bin/bash


echo "Hello friends welcome in Shell-Scripting For Linux :"
echo ""

echo "How is your 90DaysOfDevOps challenge going"
echo ""

echo "time"
date

echo ""
uptime

<< comment
This use for multi line comments
comment
